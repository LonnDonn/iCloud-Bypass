from __future__ import annotations

__version__ = "2.5.1"  # x-releaser-pleaser-version
